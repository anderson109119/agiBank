Dado (/^que acesse o site agibank$/) do

	$home=Home.new
	$home.acessar
end

Quando (/^clicar no botão pesquisar$/) do

	$elementos=Elementos.new
	$elementos.selecionabusca
end

E (/^digitar a pesquisa desejada$/) do

	$elementos.preenchepesquisa
	$elementos.selecionabusca
end

Então (/^vejo a mensagem de resultados encontrados para produtos$/) do

	@comum=Comum.new
	@comum.validarmensagem	
end

Quando (/^digitar a pesquisa com dados inexistentes$/) do

	$home.acessar
	$elementos.selecionabusca
	$elementos.preenchepesquisainvalida
	$elementos.selecionabusca
end

Então (/^vejo a mensagem de resultado não encontrado$/) do

	@comum=Comum.new
	@comum.validarmensageminvalida
end