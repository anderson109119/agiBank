class Home < SitePrism::Page	

	def acessar
		
		visit "https://blogdoagi.com.br/"		
	end	
end