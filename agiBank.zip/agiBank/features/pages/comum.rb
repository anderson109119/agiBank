class Comum < SitePrism::Page
	
	def validarmensagem

		agibankvalidador = page.find(:xpath, "//*[@id='primary']/section/h1/span")
		validaagibank = agibankvalidador.text
		if validaagibank.eql? "produtos" then nil else raise "Mensagem não encontrada" end
	end

	def validarmensageminvalida

		agibankdadosinvalidos = page.find(:css, "#main > section > div > p")
		validaagibankdadosinvalidos = agibankdadosinvalidos.text
		if validaagibankdadosinvalidos.eql? "Lamentamos, mas nada foi encontrado para sua pesquisa, tente novamente com outras palavras." then nil else raise "A mensagem esperada não foi encontrada" end
	end
end