class Elementos < SitePrism::Page

	def selecionabusca

		campopesquisa = page.find(:css, "#ast-desktop-header > div.ast-above-header-wrap > div > div > div > div.site-header-above-section-right.site-header-section.ast-flex.ast-grid-right-section > div.ast-builder-layout-element.ast-flex.site-header-focus-item.ast-header-search > div > div > a > span.ast-icon.icon-search")
		clickcampo = campopesquisa.click		
	end

	def preenchepesquisa

		preenchepesquisa = page.find(:id, "search-field").send_keys("produtos")
	end

	def preenchepesquisainvalida

		preenchepesquisa = page.find(:id, "search-field").send_keys("%%$%")
	end
end