
Before do |scenario|
    puts "agibank ..."
    puts "Iniciando cenários"
end

After do |scenario|
    puts "Cenários finalizados!"
end