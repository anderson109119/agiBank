# agiBank
Configurações realizadas com ruby, capybara,cucumber
Framework dividido em features de acordo com BDD
Para rodar entrar na raíz do projeto e executar cucumber
Para rodar um cenário digitar cucumber -t @teste1 ou cucumber -t @teste2
Obs.: As configurações de acordo com as gems setadas deverão estar presentes na máquina local de execução!